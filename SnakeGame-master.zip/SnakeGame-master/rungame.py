from mygame import app

"""
runs the game
"""

if __name__ == '__main__':
    app.run(debug=True)
    #app.run()
